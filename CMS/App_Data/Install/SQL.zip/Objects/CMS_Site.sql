SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_Site](
	[SiteID] [int] IDENTITY(1,1) NOT NULL,
	[SiteName] [nvarchar](100) NOT NULL,
	[SiteDisplayName] [nvarchar](200) NOT NULL,
	[SiteDescription] [nvarchar](max) NULL,
	[SiteStatus] [nvarchar](20) NOT NULL,
	[SiteDomainName] [nvarchar](400) NOT NULL,
	[SiteDefaultVisitorCulture] [nvarchar](50) NULL,
	[SiteGUID] [uniqueidentifier] NOT NULL,
	[SiteLastModified] [datetime2](7) NOT NULL,
	[SitePresentationURL] [nvarchar](400) NOT NULL,
 CONSTRAINT [PK_CMS_Site] PRIMARY KEY NONCLUSTERED 
(
	[SiteID] ASC
)
)
GO
SET ANSI_PADDING ON
GO
CREATE CLUSTERED INDEX [IX_CMS_Site_SiteDisplayName] ON [dbo].[CMS_Site]
(
	[SiteDisplayName] ASC
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Site_SiteDomainName_SiteStatus] ON [dbo].[CMS_Site]
(
	[SiteDomainName] ASC,
	[SiteStatus] ASC
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Site_SiteName] ON [dbo].[CMS_Site]
(
	[SiteName] ASC
)
GO
ALTER TABLE [dbo].[CMS_Site] ADD  CONSTRAINT [DEFAULT_CMS_Site_SiteName]  DEFAULT ('') FOR [SiteName]
GO
ALTER TABLE [dbo].[CMS_Site] ADD  CONSTRAINT [DEFAULT_CMS_Site_SiteDisplayName]  DEFAULT ('') FOR [SiteDisplayName]
GO
ALTER TABLE [dbo].[CMS_Site] ADD  CONSTRAINT [DEFAULT_CMS_Site_SiteStatus]  DEFAULT ('') FOR [SiteStatus]
GO
ALTER TABLE [dbo].[CMS_Site] ADD  CONSTRAINT [DEFAULT_CMS_Site_SiteDomainName]  DEFAULT ('') FOR [SiteDomainName]
GO
ALTER TABLE [dbo].[CMS_Site] ADD  CONSTRAINT [DEFAULT_CMS_Site_SitePresentationURL]  DEFAULT (N'') FOR [SitePresentationURL]
GO
